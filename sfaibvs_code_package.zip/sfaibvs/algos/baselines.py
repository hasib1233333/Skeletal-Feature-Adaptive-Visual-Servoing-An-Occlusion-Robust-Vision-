"""
baselines.py
Two classical visual-servoing feature strategies, both consuming only
the binary visible mask (target AND NOT occluder) at each step:

  - CentroidIBVS: drives image centroid and sqrt(area) to a desired
    configuration. Cannot estimate orientation from a centroid alone,
    so theta is left uncontrolled -- a real, well known limitation.
  - CornerIBVS: estimates a full similarity transform (translation,
    rotation, scale) from four convex-hull extreme points, giving
    orientation feedback that centroid IBVS lacks, but vulnerable to
    the extreme points changing identity under partial occlusion.
"""

import numpy as np
import cv2

IMG_SIZE = 128
IMG_CENTER = np.array([IMG_SIZE / 2.0, IMG_SIZE / 2.0])

# Canonical extreme points (top, bottom, left, right) of the T-shape at
# scale=1, theta=0, precomputed once from the canonical polygon's
# rasterized silhouette bounding directions.
_CANON_EXTREME = np.array([
    [0.0, -6.0],    # top-most point (of the crossbar)
    [0.0, 30.0],    # bottom-most point (stem tip)
    [-18.0, 0.0],   # left-most point (crossbar)
    [18.0, 0.0],    # right-most point (crossbar)
])


def _extreme_points(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) < 4:
        return None
    top = np.array([xs[np.argmin(ys)], ys.min()], dtype=float)
    bottom = np.array([xs[np.argmax(ys)], ys.max()], dtype=float)
    left = np.array([xs.min(), ys[np.argmin(xs)]], dtype=float)
    right = np.array([xs.max(), ys[np.argmax(xs)]], dtype=float)
    return np.stack([top, bottom, left, right])


def _similarity_from_points(canon_pts, obs_pts):
    """Least-squares similarity transform (rotation+scale+translation)
    mapping canon_pts -> obs_pts via the complex-number closed form."""
    p = canon_pts[:, 0] + 1j * canon_pts[:, 1]
    q = obs_pts[:, 0] + 1j * obs_pts[:, 1]
    pbar, qbar = p.mean(), q.mean()
    num = np.sum(np.conj(p - pbar) * (q - qbar))
    den = np.sum(np.abs(p - pbar) ** 2)
    if den < 1e-9:
        return None
    a = num / den
    b = qbar - a * pbar
    scale = np.abs(a)
    theta = np.angle(a)
    tx = b.real - IMG_CENTER[0]
    ty = b.imag - IMG_CENTER[1]
    return tx, ty, scale, theta


class CentroidIBVS:
    name = "Centroid-IBVS"

    # nominal centroid offset of the canonical T-shape from its own
    # origin (measured once at scale=1, theta=0); subtracted so that
    # the *shape's* centroid, not its arbitrary origin, is driven to
    # the desired image position.
    _NOMINAL_OFFSET = np.array([0.0, 7.28])

    def __init__(self, k_pos=0.18, k_scale=1.1, s_desired=1.0):
        self.k_pos = k_pos
        self.k_scale = k_scale
        self.s_desired = s_desired
        self.last_area = None

    def act(self, mask, occlusion_fraction):
        ys, xs = np.nonzero(mask)
        if len(xs) == 0:
            return 0.0, 0.0, 0.0, 0.0
        cx, cy = xs.mean(), ys.mean()
        area = len(xs)
        scale_est = np.sqrt(area / 620.0)  # 620 ~= canonical area at scale=1
        tx_est = cx - IMG_CENTER[0] - self._NOMINAL_OFFSET[0] * scale_est
        ty_est = cy - IMG_CENTER[1] - self._NOMINAL_OFFSET[1] * scale_est
        dtx = -self.k_pos * tx_est
        dty = -self.k_pos * ty_est
        dscale = -self.k_scale * (scale_est - self.s_desired)
        dtheta = 0.0  # centroid carries no orientation information
        return dtx, dty, dscale, dtheta


class CornerIBVS:
    """Simulates classical multi-point feature tracking using real
    image-derived corners: at each step, the visible mask's contour is
    polygon-approximated (cv2.approxPolyDP) to detect corner
    candidates, exactly as a real corner detector would. Each of the 8
    canonical T-shape vertices is predicted into the image using the
    controller's current transform estimate, then matched to the
    nearest detected corner within a small pixel radius (data
    association); vertices with no nearby detected corner are
    'lost' -- the realistic occlusion failure mode of point-feature
    IBVS. The transform is refit by least squares from whichever
    correspondences survive; with fewer than two, the previous
    transform estimate is held (tracking-dropout fallback)."""

    name = "Corner-IBVS"
    _CANON_VERTS = np.array([
        [-18, -6], [18, -6], [18, 6], [6, 6], [6, 30], [-6, 30], [-6, 6], [-18, 6],
    ], dtype=float)
    _MATCH_RADIUS = 7.0

    def __init__(self, k_pos=0.16, k_scale=1.0, k_rot=0.5, s_desired=1.0):
        self.k_pos = k_pos
        self.k_scale = k_scale
        self.k_rot = k_rot
        self.s_desired = s_desired
        self.a = 1.0 + 0j
        self.b = complex(*IMG_CENTER)
        self.initialized = False
        self.step_count = 0

    def _detect_corners(self, mask):
        m8 = (mask.astype(np.uint8)) * 255
        contours, _ = cv2.findContours(m8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return np.zeros((0,), dtype=complex)
        largest = max(contours, key=cv2.contourArea)
        peri = cv2.arcLength(largest, True)
        approx = cv2.approxPolyDP(largest, 0.02 * peri, True)
        pts = approx.reshape(-1, 2).astype(float)
        return pts[:, 0] + 1j * pts[:, 1]

    def act(self, mask, occlusion_fraction):
        self.step_count += 1
        if not self.initialized:
            ys, xs = np.nonzero(mask)
            if len(xs) > 0:
                self.b = complex(xs.mean(), ys.mean())
            self.initialized = True

        canon_complex = self._CANON_VERTS[:, 0] + 1j * self._CANON_VERTS[:, 1]
        predicted = self.a * canon_complex + self.b
        detected = self._detect_corners(mask)

        # coarse-to-fine acquisition: a real system re-detects globally
        # before local tracking has converged, so allow a wide match
        # radius for the first few frames, then tighten it
        radius = 45.0 if self.step_count <= 6 else self._MATCH_RADIUS

        detected_canon, detected_obs = [], []
        if len(detected) > 0:
            # greedy one-to-one matching: without this, multiple
            # canonical vertices can spuriously claim the same detected
            # corner when the current transform estimate is still far
            # from correct, which corrupts the least-squares fit
            pairs = []
            for i, pred_pt in enumerate(predicted):
                d = np.abs(detected - pred_pt)
                j = np.argmin(d)
                if d[j] < radius:
                    pairs.append((d[j], i, j))
            pairs.sort(key=lambda t: t[0])
            used_canon, used_det = set(), set()
            for dist, i, j in pairs:
                if i in used_canon or j in used_det:
                    continue
                used_canon.add(i)
                used_det.add(j)
                detected_canon.append(canon_complex[i])
                detected_obs.append(detected[j])

        if len(detected_canon) >= 3:
            p = np.array(detected_canon)
            q = np.array(detected_obs)
            pbar, qbar = p.mean(), q.mean()
            num = np.sum(np.conj(p - pbar) * (q - qbar))
            den = np.sum(np.abs(p - pbar) ** 2)
            if den > 1e-9:
                new_a = num / den
                new_b = qbar - new_a * pbar
                # outlier-rejection sanity guard: a single bad
                # correspondence can otherwise produce an unphysical
                # jump; a real robust estimator (e.g. RANSAC) would
                # reject this the same way
                if 0.08 < np.abs(new_a) < 6.0:
                    self.a, self.b = new_a, new_b

        scale_est = np.abs(self.a)
        theta_est = np.angle(self.a)
        tx_est = self.b.real - IMG_CENTER[0]
        ty_est = self.b.imag - IMG_CENTER[1]

        dtx = -self.k_pos * tx_est
        dty = -self.k_pos * ty_est
        dscale = -self.k_scale * (scale_est - self.s_desired)
        dtheta = -self.k_rot * theta_est
        return dtx, dty, dscale, dtheta
