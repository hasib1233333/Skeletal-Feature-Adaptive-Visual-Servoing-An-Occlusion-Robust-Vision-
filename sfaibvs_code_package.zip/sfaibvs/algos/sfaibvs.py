"""
sfaibvs.py
SF-AIBVS: Skeletal-Feature Adaptive Image-Based Visual Servoing.

Feature extraction (per step):
  1. Compute the morphological skeleton of the visible binary mask.
  2. Position estimate = centroid of skeleton pixels, corrected for
     the canonical shape's own skeleton-centroid offset (rotated and
     scaled into the current frame using the orientation/scale
     estimates below).
  3. Scale estimate = observed skeleton pixel count / canonical
     skeleton length at unit scale.
  4. Orientation estimate = bearing from the skeleton centroid to the
     farthest skeleton endpoint (the T-shape's unique stem tip), which
     is unambiguous over the full 2*pi range, unlike a PCA principal
     axis.

Confidence gate:
  A running "trusted scale" estimate, updated only on confidently
  measured steps, predicts the skeleton length expected this step. The
  ratio of observed to expected skeleton length is the confidence
  signal. When confidence falls below a threshold (substantial
  occlusion), the control output is frozen (zero command) rather than
  computed from the corrupted measurement -- a deliberately simple and
  provably stable fallback: since no command is issued, the true state
  cannot drift away from the frozen reference while confidence is low,
  which avoids the runaway/staleness failure mode that a naive
  constant-velocity extrapolation was found to produce during
  development (see paper Sec. VI for the ablation and discussion).
"""

import numpy as np
from skimage.morphology import skeletonize
from skimage.draw import polygon as sk_polygon
from scipy.ndimage import convolve

IMG_SIZE = 128
IMG_CENTER = np.array([IMG_SIZE / 2.0, IMG_SIZE / 2.0])

_CANON_T = np.array([
    [-18, -6], [18, -6], [18, 6], [6, 6], [6, 30], [-6, 30], [-6, 6], [-18, 6],
], dtype=float)


def _canonical_skeleton_length():
    rr, cc = sk_polygon(_CANON_T[:, 1] + IMG_CENTER[1], _CANON_T[:, 0] + IMG_CENTER[0],
                         shape=(IMG_SIZE, IMG_SIZE))
    m = np.zeros((IMG_SIZE, IMG_SIZE), dtype=bool)
    m[rr, cc] = True
    return skeletonize(m).sum()


_CANON_SKEL_LEN = _canonical_skeleton_length()
_NOMINAL_SKEL_OFFSET = np.array([0.0, 5.84])

_NEIGHBOR_KERNEL = np.array([[1, 1, 1], [1, 10, 1], [1, 1, 1]])


def _skeleton_endpoints(skel):
    conv = convolve(skel.astype(int), _NEIGHBOR_KERNEL, mode="constant", cval=0)
    endpoints = skel & (conv == 11)
    ys, xs = np.nonzero(endpoints)
    return xs, ys


def _stem_tip_angle(skel, cx, cy, prev_angle):
    """Bearing from the skeleton centroid to the farthest skeleton
    endpoint (the T-shape's stem tip) -- unambiguous mod 2*pi, unlike a
    PCA principal axis which only resolves orientation mod pi."""
    ex, ey = _skeleton_endpoints(skel)
    if len(ex) == 0:
        return prev_angle if prev_angle is not None else 0.0
    d = np.hypot(ex - cx, ey - cy)
    tip = np.argmax(d)
    raw = np.arctan2(ey[tip] - cy, ex[tip] - cx) - np.pi / 2
    return ((raw + np.pi) % (2 * np.pi)) - np.pi


class SFAIBVSController:
    def __init__(self, k_pos=0.17, k_scale=1.05, k_rot=0.55, s_desired=1.0,
                 conf_thresh=0.45, disable_gate=False):
        self.k_pos = k_pos
        self.k_scale = k_scale
        self.k_rot = k_rot
        self.s_desired = s_desired
        self.conf_thresh = conf_thresh
        self.disable_gate = disable_gate

        self.trusted_scale = None
        self.prev_angle = None
        self.confidence_log = []
        self.mode_log = []

    def act(self, mask, occlusion_fraction_true_unused=None):
        skel = skeletonize(mask)
        ys, xs = np.nonzero(skel)

        if len(xs) < 3:
            observed_len = 0
            raw_est = None
        else:
            observed_len = len(xs)
            cx, cy = xs.mean(), ys.mean()
            scale_est = observed_len / _CANON_SKEL_LEN
            theta_est = _stem_tip_angle(skel, cx, cy, self.prev_angle)
            c, s = np.cos(theta_est), np.sin(theta_est)
            off = scale_est * np.array([c * _NOMINAL_SKEL_OFFSET[0] - s * _NOMINAL_SKEL_OFFSET[1],
                                         s * _NOMINAL_SKEL_OFFSET[0] + c * _NOMINAL_SKEL_OFFSET[1]])
            tx_est = cx - IMG_CENTER[0] - off[0]
            ty_est = cy - IMG_CENTER[1] - off[1]
            raw_est = np.array([tx_est, ty_est, scale_est, theta_est])

        if self.trusted_scale is None:
            self.trusted_scale = raw_est[2] if raw_est is not None else 1.0

        expected_len = max(self.trusted_scale, 0.1) * _CANON_SKEL_LEN
        confidence = observed_len / max(expected_len, 1e-6)
        confidence = float(np.clip(confidence, 0.0, 1.5))
        self.confidence_log.append(confidence)

        low_confidence = (confidence < self.conf_thresh) or (raw_est is None)

        if (not self.disable_gate) and low_confidence:
            # freeze: issue no command while confidence is low, rather
            # than acting on a corrupted or absent measurement. Because
            # nothing moves, the trusted-scale reference does not go
            # stale relative to the (unchanged) true state, so
            # confidence can recover cleanly once occlusion clears.
            self.mode_log.append("frozen")
            return 0.0, 0.0, 0.0, 0.0

        if raw_est is None:
            self.mode_log.append("frozen")
            return 0.0, 0.0, 0.0, 0.0

        self.mode_log.append("measured")
        self.trusted_scale = 0.75 * self.trusted_scale + 0.25 * raw_est[2]
        self.prev_angle = raw_est[3]

        tx_est, ty_est, scale_est, theta_est = raw_est
        dtx = -self.k_pos * tx_est
        dty = -self.k_pos * ty_est
        dscale = -self.k_scale * (scale_est - self.s_desired)
        dtheta = -self.k_rot * theta_est
        return dtx, dty, dscale, dtheta

    def reset(self):
        self.trusted_scale = None
        self.prev_angle = None
        self.confidence_log = []
        self.mode_log = []
