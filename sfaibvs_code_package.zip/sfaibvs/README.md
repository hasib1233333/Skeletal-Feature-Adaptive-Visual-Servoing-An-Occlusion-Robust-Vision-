# SF-AIBVS: Skeletal-Feature Adaptive Visual Servoing

Complete, runnable implementation accompanying "Skeletal-Feature Adaptive
Visual Servoing: An Occlusion-Robust Vision-Control Framework for Robotic
Manipulators" (AUSMT Special Issue 26-01-01, AI-Driven Vision Systems and
Intelligent Control in Robotics).

## Contents

- `sim/environment.py` -- synthetic docking environment: a T-shaped
  target rendered under a hidden pose (tx, ty, scale, theta), a moving
  rectangular occluder, and a binary-mask observation function.
- `algos/baselines.py` -- Centroid-IBVS and Corner-IBVS baseline
  controllers. Corner-IBVS includes real contour/corner detection
  (OpenCV `approxPolyDP`), one-to-one correspondence matching, and
  outlier rejection, not a toy simplification of either method.
- `algos/sfaibvs.py` -- the proposed SF-AIBVS controller: skeleton
  feature extraction, unambiguous stem-tip orientation estimation, and
  the confidence gate.
- `experiments/run_experiments.py` -- runs all (controller, severity,
  seed) combinations; `--controller` / `--severity` / `--n_seeds` flags
  allow chunked execution.
- `experiments/analyze.py` -- summary statistics and paired
  significance tests (exact binomial on success, Wilcoxon signed-rank
  on steps-to-converge and smoothness).
- `results/` -- raw per-trial results (360 rows: 4 controllers x 3
  severities x 30 seeds) and the derived summary/significance tables
  used directly in the paper.
- `figures/` -- all figures embedded in the paper.

## Reproducing the results

```bash
pip install numpy scipy pandas matplotlib scikit-image opencv-python --break-system-packages

for sev in light moderate heavy; do
  for c in Centroid Corner SF-AIBVS SF-AIBVS-NoGate; do
    python experiments/run_experiments.py --controller "$c" --severity "$sev" --n_seeds 30
  done
done

python experiments/analyze.py
```

## Honesty notes

- All numbers in the paper come directly from `results/raw_results.csv`;
  nothing was hand-edited.
- The confidence gate's benefit is reported exactly as measured: no
  significant change in success rate or steps-to-converge at any
  severity, and a significant (p=0.0069) smoothness improvement only
  at heavy occlusion. We did not find, and did not report, a larger
  effect than this.
- An earlier version of SF-AIBVS used constant-velocity feature
  extrapolation during low confidence instead of freezing. It produced
  unbounded drift during long occlusions because a stale, non-zero
  correction kept being applied every step against a target that had
  stopped moving. This is documented in the paper's Discussion section
  rather than quietly discarded, and `algos/sfaibvs.py` implements the
  freeze-based design that replaced it.
- Both baselines received the same continuous-throttling treatment
  applied to SF-AIBVS's fallback logic during development, and
  Corner-IBVS specifically required a coarse-to-fine acquisition
  radius and one-to-one correspondence matching to avoid spurious
  divergence unrelated to occlusion. Neither baseline is a deliberately
  weakened strawman.
- The canonical shape tested is a single T-shape. No claim is made
  about shapes lacking a single dominant skeleton branch or with
  rotational symmetry, where the stem-tip orientation estimate would
  need modification; this is stated as a limitation in the paper.

## Known limitations (see paper Section VII)

- Planar, orthographic 4-parameter pose model, not full 6-DOF
  perspective IBVS.
- Single target shape (T); generalization to other topologies untested.
- Single rigid rectangular occluder with a simple sweep trajectory.
- Gate threshold and control gains set during development, not tuned
  on a held-out validation split.
- Clean synthetic masks only; no real camera or segmentation noise.
