import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
from sim.environment import VisualServoEnv
from algos.baselines import CentroidIBVS, CornerIBVS
from algos.sfaibvs import SFAIBVSController


def smoothness(commands):
    c = np.array(commands)
    if len(c) < 2:
        return 0.0
    d = np.diff(c, axis=0)
    return float(np.mean(np.linalg.norm(d, axis=1)))


def run_episode(controller_name, seed, severity, max_steps=800):
    env = VisualServoEnv(severity=severity, seed=seed, max_steps=max_steps)

    if controller_name == "Centroid":
        ctrl = CentroidIBVS()
    elif controller_name == "Corner":
        ctrl = CornerIBVS()
    elif controller_name == "SF-AIBVS":
        ctrl = SFAIBVSController()
    elif controller_name == "SF-AIBVS-NoGate":
        ctrl = SFAIBVSController(disable_gate=True)
    else:
        raise ValueError(controller_name)

    commands = []
    t0 = time.time()
    step_times = []
    while True:
        mask, occf = env.observe()
        ts = time.time()
        dtx, dty, dscale, dtheta = ctrl.act(mask, occf)
        step_times.append(time.time() - ts)
        commands.append((dtx, dty, dscale, dtheta))
        done = env.step(dtx, dty, dscale, dtheta)
        if done:
            break
    wall_time = time.time() - t0

    pos_err, scale_err, theta_err = env.pose_error()
    frozen_frac = None
    if hasattr(ctrl, "mode_log") and len(ctrl.mode_log) > 0:
        frozen_frac = ctrl.mode_log.count("frozen") / len(ctrl.mode_log)

    result = dict(
        controller=controller_name, seed=seed, severity=severity,
        success=int(env.reached), diverged=int(env.diverged),
        timeout=int((not env.reached) and (not env.diverged)),
        steps=env.t,
        time_to_converge=env.t if env.reached else np.nan,
        final_pos_err=pos_err, final_scale_err=scale_err, final_theta_err=theta_err,
        smoothness=smoothness(commands),
        frozen_fraction=frozen_frac,
        mean_step_time_ms=1000 * np.mean(step_times),
    )
    return result


DENSITIES = {"light": "light", "moderate": "moderate", "heavy": "heavy"}


def main_chunk(controller, severity, seeds):
    rows = []
    for seed in seeds:
        r = run_episode(controller, seed, severity)
        rows.append(r)
    df = pd.DataFrame(rows)
    out_dir = os.path.join(os.path.dirname(__file__), "..", "results", "chunks")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"{controller}_{severity}.csv")
    df.to_csv(out_path, index=False)
    print("saved", out_path, len(df), "rows")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--controller", required=True)
    p.add_argument("--severity", required=True)
    p.add_argument("--n_seeds", type=int, default=30)
    args = p.parse_args()
    main_chunk(args.controller, args.severity, list(range(args.n_seeds)))
