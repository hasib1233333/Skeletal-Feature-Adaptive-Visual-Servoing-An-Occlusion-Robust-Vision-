import pandas as pd
import numpy as np
from scipy import stats

df = pd.read_csv("/home/claude/sfaibvs/results/raw_results.csv")

summary_rows = []
for (sev, ctrl), g in df.groupby(["severity", "controller"]):
    ok = g[g["success"] == 1]
    summary_rows.append(dict(
        severity=sev, controller=ctrl, n=len(g),
        success_rate=g["success"].mean(),
        diverged_rate=g["diverged"].mean(),
        timeout_rate=g["timeout"].mean(),
        steps_mean=ok["steps"].mean() if len(ok) else np.nan,
        steps_std=ok["steps"].std() if len(ok) else np.nan,
        final_pos_err_mean=ok["final_pos_err"].mean() if len(ok) else np.nan,
        final_scale_err_mean=ok["final_scale_err"].mean() if len(ok) else np.nan,
        final_theta_err_mean=ok["final_theta_err"].mean() if len(ok) else np.nan,
        final_pos_err_mean_all=g["final_pos_err"].mean(),
        final_scale_err_mean_all=g["final_scale_err"].mean(),
        final_theta_err_mean_all=g["final_theta_err"].mean(),
        smoothness_mean=g["smoothness"].mean(),
        smoothness_std=g["smoothness"].std(),
        frozen_fraction_mean=g["frozen_fraction"].mean(),
        step_time_ms_mean=g["mean_step_time_ms"].mean(),
    ))

summary = pd.DataFrame(summary_rows)
summary.to_csv("/home/claude/sfaibvs/results/summary_table.csv", index=False)
pd.set_option("display.width", 220)
pd.set_option("display.max_columns", 20)
print(summary.round(3).to_string(index=False))

print("\n=== Significance: SF-AIBVS vs Corner (success), and vs NoGate (steps-to-converge) ===")
sig_rows = []
for sev in ["light", "moderate", "heavy"]:
    ref = df[(df.severity == sev) & (df.controller == "SF-AIBVS")].sort_values("seed")
    for other in ["Centroid", "Corner", "SF-AIBVS-NoGate"]:
        cmp = df[(df.severity == sev) & (df.controller == other)].sort_values("seed")
        merged = ref.merge(cmp, on="seed", suffixes=("_sf", "_other"))
        disc_sf_wins = int(((merged.success_sf == 1) & (merged.success_other == 0)).sum())
        disc_other_wins = int(((merged.success_sf == 0) & (merged.success_other == 1)).sum())
        n_disc = disc_sf_wins + disc_other_wins
        p_mcnemar = stats.binomtest(disc_sf_wins, n_disc, 0.5).pvalue if n_disc > 0 else 1.0
        # steps-to-converge comparison only meaningful where both succeed
        both_ok = merged[(merged.success_sf == 1) & (merged.success_other == 1)]
        if len(both_ok) >= 5:
            try:
                w_stat, p_steps = stats.wilcoxon(both_ok["steps_sf"], both_ok["steps_other"])
            except ValueError:
                p_steps = np.nan
        else:
            p_steps = np.nan
        sig_rows.append(dict(severity=sev, baseline=other,
                              sf_success=merged.success_sf.mean(),
                              other_success=merged.success_other.mean(),
                              mcnemar_p=p_mcnemar,
                              n_both_succeeded=len(both_ok),
                              wilcoxon_steps_p=p_steps))
sig = pd.DataFrame(sig_rows)
sig.to_csv("/home/claude/sfaibvs/results/significance_table.csv", index=False)
print(sig.round(4).to_string(index=False))
