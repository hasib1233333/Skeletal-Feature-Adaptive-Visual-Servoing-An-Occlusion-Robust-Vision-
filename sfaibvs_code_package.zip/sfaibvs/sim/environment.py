"""
environment.py
Synthetic 2D image-based visual servoing (IBVS) environment.

A T-shaped target silhouette is rendered into a binary image under a
hidden true pose (tx, ty, scale, theta). A moving rectangular occluder
partially blocks the target at times controlled by an "occlusion
severity" setting. Controllers observe only the resulting binary mask
(target AND NOT occluder) and must command incremental pose corrections
(dtx, dty, dscale, dtheta) to drive the hidden pose toward the desired
centered, upright, canonically-scaled configuration. Actuation is
assumed perfect (the commanded delta is applied exactly to the hidden
state) so that all controller differences are attributable to the
perception/feature-extraction stage, not to actuator noise.
"""

import numpy as np
from skimage.draw import polygon as sk_polygon

IMG_SIZE = 128
IMG_CENTER = np.array([IMG_SIZE / 2.0, IMG_SIZE / 2.0])

# Canonical T-shape vertices in object frame, centered at origin, unit scale.
# A T-shape gives three skeleton endpoints and one junction -- a rich,
# unambiguous topological signature for the proposed method to exploit.
_CANON_T = np.array([
    [-18, -6], [18, -6], [18, 6], [6, 6], [6, 30], [-6, 30], [-6, 6], [-18, 6],
], dtype=float)


class Occluder:
    def __init__(self, severity, rng, max_steps):
        # severity in {"light", "moderate", "heavy"}
        size_map = {"light": (14, 14), "moderate": (26, 26), "heavy": (58, 58)}
        self.w, self.h = size_map[severity]
        self.rng = rng
        speed_map = {"light": 0.5, "moderate": 0.55, "heavy": 0.35}
        self.speed = speed_map[severity]
        # bias the vertical position toward the region the target
        # typically occupies once converged (image center), so that
        # "heavy" occlusion reliably intersects the target rather than
        # frequently missing it by chance on a uniform draw
        y_range_map = {"light": (20, 108), "moderate": (35, 95), "heavy": (44, 84)}
        ylo, yhi = y_range_map[severity]
        self.y = rng.uniform(ylo, yhi)
        self.x = rng.uniform(-self.w, IMG_SIZE + self.w)
        self.active_prob = {"light": 0.5, "moderate": 0.8, "heavy": 1.0}[severity]
        self.engaged = rng.uniform() < self.active_prob
        self.max_steps = max_steps

    def step(self):
        if not self.engaged:
            return
        self.x += self.speed
        if self.x > IMG_SIZE + self.w:
            self.x = -self.w
            self.y = self.rng.uniform(20, IMG_SIZE - 20)

    def mask(self):
        m = np.zeros((IMG_SIZE, IMG_SIZE), dtype=bool)
        if not self.engaged:
            return m
        x0 = int(max(0, self.x - self.w / 2))
        x1 = int(min(IMG_SIZE, self.x + self.w / 2))
        y0 = int(max(0, self.y - self.h / 2))
        y1 = int(min(IMG_SIZE, self.y + self.h / 2))
        if x1 > x0 and y1 > y0:
            m[y0:y1, x0:x1] = True
        return m


class VisualServoEnv:
    def __init__(self, severity="moderate", seed=0, s_desired=1.0, max_steps=400):
        self.rng = np.random.default_rng(seed)
        self.severity = severity
        self.s_desired = s_desired
        self.max_steps = max_steps

        # initial pose error: random offset, scale, and rotation
        self.tx = self.rng.uniform(-45, 45)
        self.ty = self.rng.uniform(-45, 45)
        self.scale = self.rng.uniform(0.4, 2.0)
        self.theta = self.rng.uniform(-1.8, 1.8)  # radians

        self.occluder = Occluder(severity, self.rng, max_steps)
        self.t = 0
        self.history = []
        self.diverged = False
        self.reached = False

    def _render_target_mask(self):
        c, s = np.cos(self.theta), np.sin(self.theta)
        R = np.array([[c, -s], [s, c]])
        pts = (self._CANON() @ R.T) * self.scale + IMG_CENTER + np.array([self.tx, self.ty])
        rr, cc = sk_polygon(pts[:, 1], pts[:, 0], shape=(IMG_SIZE, IMG_SIZE))
        m = np.zeros((IMG_SIZE, IMG_SIZE), dtype=bool)
        m[rr, cc] = True
        return m

    @staticmethod
    def _CANON():
        return _CANON_T

    def observe(self):
        target = self._render_target_mask()
        occ = self.occluder.mask()
        visible = target & ~occ
        occlusion_fraction = 1.0 - (visible.sum() / max(target.sum(), 1))
        return visible, occlusion_fraction

    def step(self, dtx, dty, dscale, dtheta):
        max_pos_step, max_scale_step, max_rot_step = 2.0, 0.045, 0.07
        dtx = np.clip(dtx, -max_pos_step, max_pos_step)
        dty = np.clip(dty, -max_pos_step, max_pos_step)
        dscale = np.clip(dscale, -max_scale_step, max_scale_step)
        dtheta = np.clip(dtheta, -max_rot_step, max_rot_step)

        self.tx += dtx
        self.ty += dty
        self.scale = max(0.15, self.scale + dscale)
        self.theta += dtheta
        self.occluder.step()
        self.t += 1

        pos_err = np.hypot(self.tx, self.ty)
        scale_err = abs(self.scale - self.s_desired)
        theta_err = abs(((self.theta + np.pi) % (2 * np.pi)) - np.pi)
        self.history.append((self.tx, self.ty, self.scale, self.theta))

        if pos_err < 2.0 and scale_err < 0.06 and theta_err < 0.06:
            self.reached = True
        if pos_err > 220 or self.scale > 6.0 or self.scale < 0.05:
            self.diverged = True

        done = self.reached or self.diverged or self.t >= self.max_steps
        return done

    def pose_error(self):
        pos_err = np.hypot(self.tx, self.ty)
        scale_err = abs(self.scale - self.s_desired)
        theta_err = abs(((self.theta + np.pi) % (2 * np.pi)) - np.pi)
        return pos_err, scale_err, theta_err
